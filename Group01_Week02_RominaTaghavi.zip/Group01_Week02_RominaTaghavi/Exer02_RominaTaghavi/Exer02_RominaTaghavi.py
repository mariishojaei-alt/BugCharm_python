age=int(input("enter your age: "))
temp=float(input("enter the body temperature: "))

if age>40:
    if temp>37:
        print("Warning!")
    else:
        print("Take care!")
else:
    if temp>37:
        print("Take care!")
    else:
        print("Every thing is fine!")