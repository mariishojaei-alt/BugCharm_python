max_G=0
count=0
base=input("Enter A, C, G or T, anything else to exit: ")

while base=="A" or base=="C" or base=="G" or base=="T":

    if base=="G":
        count=count+1
        if count>max_G:
            max_G=count
        
    else:
        count=0

    base=input("Enter A, C, G or T, anything else to exit: ")


print(max_G)

