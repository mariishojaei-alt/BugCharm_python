min=100
max=-100

for i in range(10):
    temp=float(input("Enter temperature: "))

    if temp<min:
        min=temp
    elif temp>max:
        max=temp

print("The maximum temperature was",max,"and the minimum temperature was",min)