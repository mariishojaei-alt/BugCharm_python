ill=1
population=1000
day=0

while ill<population:
    if ill<=500:
        new_ill=ill*2
        ill=ill+new_ill
        day=day+1

    else:
        new_ill=ill*0.5
        ill=ill+new_ill
        day=day+1

print("It takes",day,"days for all the population to get this disease")