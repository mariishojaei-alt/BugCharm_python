# Population parameters
population = 1000
infected = 1
days = 0

while infected < population:
    days += 1
    if infected <= 500:
        # before quarantine: each infected infects 2 new people
        new_infections = infected * 2
    else:
        # after quarantine: each infected infects 0.5 new people
        new_infections = infected * 0.5

    infected += new_infections

    # cap at total population
    if infected > population:
        infected = population

print("Total days until all infected:", days)
