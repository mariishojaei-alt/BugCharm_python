passcode=1234
n=int(input("enter the passcode: "))

while n!=passcode:
    n=int(input("Wrong passcode! try again: "))

print("Welcome to the lab!")