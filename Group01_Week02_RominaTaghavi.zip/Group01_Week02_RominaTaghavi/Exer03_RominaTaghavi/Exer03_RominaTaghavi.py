start=13
for count in range(start,1,-1):
    print(count)
print("Lift_off!")
