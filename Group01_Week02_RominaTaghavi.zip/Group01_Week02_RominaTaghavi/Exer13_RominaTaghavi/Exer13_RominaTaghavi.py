height=10
count=0

while height>=0.1:
    height=height*0.8
    count=count+1

print("it takes",count,"times for the ball to reach less than 10cms")