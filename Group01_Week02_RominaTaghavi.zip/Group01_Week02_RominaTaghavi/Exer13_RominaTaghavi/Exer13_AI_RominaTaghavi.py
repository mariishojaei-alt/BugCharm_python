# initial height
height = 10.0   # meters
limit = 0.1     # meters
count = 0

# loop until height < limit
while height >= limit:
    count += 1
    height *= 0.8   # after each bounce, height is 80% of previous

print("Number of bounces:", count)
