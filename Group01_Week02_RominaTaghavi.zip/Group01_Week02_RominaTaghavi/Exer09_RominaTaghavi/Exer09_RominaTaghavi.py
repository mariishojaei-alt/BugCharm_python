broken=0
working=0

for i in range(9):
    state=int(input("enter 0 for broken and 1 for working products: "))

    if state==0:
        broken=broken+1
    else:
        working=working+1
        

print("There are",working,"working and",broken,"broken products")