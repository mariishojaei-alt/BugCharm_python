right_num=7

guess=int(input("enter your guess: "))

while guess!=right_num:
    if guess<7:
        guess=int(input("enter a bigger number: "))

    else:
        guess=int(input("enter a smaller number: "))

print("thats right!")

        
