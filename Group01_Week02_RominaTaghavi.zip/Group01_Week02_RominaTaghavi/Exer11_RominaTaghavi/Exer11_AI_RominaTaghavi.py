# Newton's method to compute square root

# Get input from user
N = float(input("Enter a non-negative number: "))

# Handle special cases
if N < 0:
    print("Error: Cannot compute square root of a negative number.")
elif N == 0:
    print("The square root of 0 is 0.")
else:
    # Initial guess
    x = N if N >= 1 else 1.0

    # Tolerance and max iterations
    epsilon = 1e-12
    max_iter = 1000

    for _ in range(max_iter):
        x_next = 0.5 * (x + N / x)
        if abs(x_next - x) < epsilon:
            break
        x = x_next

    # Output result
    print(f"Approximate square root of {N} is: {x_next}")

