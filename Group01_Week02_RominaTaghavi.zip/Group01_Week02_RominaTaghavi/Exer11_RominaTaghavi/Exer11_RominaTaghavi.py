a=float(input("enter a number: "))

X_old=a
X_new=a/2
while abs(X_new**2-a)>10**(-6):

    X_old=X_new

    f= X_old**2-a
    f_prime= 2*X_old

    X_new= X_old-(f/f_prime)

    #print(X_new)
    
print("The square root is:",X_new)