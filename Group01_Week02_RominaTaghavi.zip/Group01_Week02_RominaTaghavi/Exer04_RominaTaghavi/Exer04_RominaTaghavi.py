electric_charge= +2
charged_particles= 10

sum=0
for i in range(1,charged_particles+1,1):
    sum=sum+electric_charge

print("Summation of the elecrtic_charges of the particles is : +",sum)
