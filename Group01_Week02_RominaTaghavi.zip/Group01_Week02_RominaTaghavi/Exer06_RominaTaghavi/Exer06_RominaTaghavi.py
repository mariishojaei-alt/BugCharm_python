pipette_capacity=20
drop_volume=3

volume=0
drops=0

while volume+drop_volume<=pipette_capacity:
    volume=volume+drop_volume
    drops=drops+1

print(drops,"drops and",volume,"mm")

